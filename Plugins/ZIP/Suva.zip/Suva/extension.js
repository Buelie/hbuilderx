var hx = require("hbuilderx");
//该方法将在插件激活的时候调用
function activate(context) {
	let disposable = hx.commands.registerCommand('extension.helloWorld', () => {
		hx.window.showInformationMessage('请求失败!!!');
	});
	let one = hx.commands.registerCommand('extension.one', () => {
		hx.window.showInformationMessage('GitHub响应:502');
	});
	let two = hx.commands.registerCommand('extension.two', () => {
		hx.window.showInformationMessage('GitCode响应:500');
	});
	let three = hx.commands.registerCommand('extension.three', () => {
		hx.window.showInformationMessage('Gitee响应:400');
	});
	let four = hx.commands.registerCommand('extension.four', () => {
		hx.window.showInformationMessage('打包失败');
	});
	let five = hx.commands.registerCommand('extension.five', () => {
		hx.window.showInformationMessage('上传过程中出错请重试');
	});
	let six = hx.commands.registerCommand('extension.six', () => {
		hx.window.showInformationMessage('网络错误,无法下载');
	});
	let seven = hx.commands.registerCommand('extension.seven', () => {
		hx.window.showInformationMessage('检测过程中出现BUG,终止检测');
	});
	let eight = hx.commands.registerCommand('extension.eight', () => {
		hx.window.showInformationMessage('无法更正,韩国阻止了网络');
	});
	let night = hx.commands.registerCommand('extension.night', () => {
		hx.window.showInformationMessage('访问源文件失败');
	});
	let ten = hx.commands.registerCommand('extension.ten', () => {
		hx.window.showInformationMessage('无法链接到您的账户');
	});
	//订阅销毁钩子，插件禁用的时候，自动注销该command。
	context.subscriptions.push(disposable);
	context.subscriptions.push(one);
}
//该方法将在插件禁用的时候调用（目前是在插件卸载的时候触发）
function deactivate() {

}
module.exports = {
	activate,
	deactivate
}
